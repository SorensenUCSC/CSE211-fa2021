x = input()
y = input()
x = y
y = x
z = input()
y = z
