x = input()

if x:
    y = x
else:
    z = x

w = y
