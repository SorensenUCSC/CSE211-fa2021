
t = input()
c = input()
x = input()
w = input()

while c:
    if t:
        t = c
        y = t
    if c:
        x = c
    w = x

y = w

