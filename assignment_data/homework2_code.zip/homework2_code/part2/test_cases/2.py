x = input()
y = input()
x = y
y = w
z = input()
y = z
