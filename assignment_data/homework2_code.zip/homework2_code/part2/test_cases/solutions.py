solutions = {
    0: set({}),
    1: set({'y'}),
    2: set({'w'}),
    3: set({'y'}),
    4: set({'w', 'x'}),
    5: set({}),
    6: set({'y'}),
    7: set({}),
             }

