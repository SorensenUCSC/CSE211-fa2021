
t = input()
c = input()
x = input()
w = input()

while c:
    if x:
        y = input()
        if w:
            x = w
        else:
            z = y
    if t:
        w = y

