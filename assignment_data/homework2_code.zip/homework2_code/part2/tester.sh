
for i in {0..7}
	 do
	 python3 tester.py $i
done
	 
