for i in range(0,10):
    read_index(5)
    write_index(i)
