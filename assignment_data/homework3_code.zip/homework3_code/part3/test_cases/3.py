for i in range(0,11):
    for j in range(0,10):
        read_index(57)
        write_index(i*j)
