for i in range(0,10):
    read_index(11)
    write_index(i)
