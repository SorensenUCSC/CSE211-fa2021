for i in range(7,10):
    for j in range(5,500):
        for k in range(i,10):
            read_index(k)
            write_index(i*j*k)
